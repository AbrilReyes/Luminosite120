<?php

//  return  array[
//     'client_id'=> env( key: 'PAYPAL_CLIENT_ID'),
//     'secret'=> env(key:'PAYPAL_SECRET'),

//     'settings'=>[
//         'mode'=>env(key:'PAYPAL_MODE',default:'sandbox'),
//         'http.conectionTimeOut'=>30,
//         'log.LogEnabled'=>true,
//         'log.Filname'=>storage_path(path:'/logs/paypal.log'),
//         'log.LogLevel'=> 'ERROR'
//     ]
//     ]
    ;