<!DOCTYPE HTML>
<html lang="es">

<head>
	<title>Registrarse</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />
	<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"> </script>
</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


				<form action="<?php echo e(route ('guardar')); ?>" method="POST" name="nuevo" enctype="multipart/form-data">

					<?php echo e(csrf_field()); ?>


					
					<div>
						Matricula : <input type="text" name="matricula"  minlength="9"  value="<?php echo e(old('matricula')); ?>">
					</div>
					<?php if($errors->first('matricula')): ?> <i><?php echo e($errors -> first ('matricula')); ?></i><?php endif; ?>
					<div>
						Nombre : <input type="text" name="nombre"  value="<?php echo e(old('nombre')); ?>">
					</div>
					<?php if($errors->first('nombre')): ?> <i><?php echo e($errors -> first ('nombre')); ?></i><?php endif; ?>

					<div>
						Email : <input type="email" name="email" value="<?php echo e(old('email')); ?>">
					</div>
					<?php if($errors->first('email')): ?> <i><?php echo e($errors -> first ('email')); ?></i><?php endif; ?>

					<div>
						Apellido Paterno : <input type="text" name="app" value="<?php echo e(old('app')); ?>">
					</div>
					<?php if($errors->first('app')): ?> <i><?php echo e($errors -> first ('app')); ?></i><?php endif; ?>

					<div>
						Apellido Materno : <input type="text" name="apm" value="<?php echo e(old('apm')); ?>">
					</div>
					<?php if($errors->first('apm')): ?> <i><?php echo e($errors -> first ('apm')); ?></i><?php endif; ?>
					<div>
					Telefono : <input type="tel" name="tel"   value="<?php echo e(old('tel')); ?>">
					<?php if($errors->first('tel')): ?> <i><?php echo e($errors -> first ('tel')); ?></i><?php endif; ?>
					</div>
					<div>Fecha de nacimiento : <input type="date" name="fn" minlength="9">
						<?php if($errors->first('fn')): ?> <i><?php echo e($errors -> first ('fn')); ?></i><?php endif; ?>
						</div>
					<div>
						Password : <input  type="password" name="pass"  minlength="8"  value="<?php echo e(old('pass')); ?>">
					</div>
					<?php if($errors->first('pass')): ?> <i><?php echo e($errors -> first ('pass')); ?></i><?php endif; ?> 
					<br>
					Imagen : <input type="file" name="img"><br>
				<br>
				
				<?php if(session('session_tipo') == 1): ?>
				<div>
					Tipo Usuario : <input  type="text" name="tipo_usuario"   placeholder="Administrador = 1  Cliente = 3" value="<?php echo e(old('tipo_usuario')); ?>">
				</div>
				<?php if($errors->first('tipo_usuario')): ?> <i><?php echo e($errors -> first ('tipo_usuario')); ?></i><?php endif; ?> <br>
				<?php endif; ?>

					<div class="form-check">
						<input class="form-check-label" type="checkbox"  id="aviso" name="aviso" >
						<?php if($errors->first('aviso')): ?> <i><?php echo e($errors -> first ('aviso')); ?></i><?php endif; ?>
							
							<a href="<?php echo e(route('aviso')); ?>">Aviso de Privacidad
						</label>
					  </div>
					<br>
					
					<input type="submit" value="Enviar">
					
				</form>
			
			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<script >

		
	const $matricula =document.querySelector("#matricula");
	const patronM = /[0-9]+/;
		$matricula.addEventListener("keydown", event => { 
			if (patronM.test(event.key)) {
				document.getElementById('matricula').style.border = "1px solid #00cc00";
			} else {
				if (event.keyCode == 8) {} else {
					event.preventDefault();
				}
			}
		});
	
		const $nombre =document.querySelector("#nombre");
		const patronNombre = /[a-zA-Z]+/;
	
		$nombre.addEventListener("keydown", event => {
			if (patronnombre.test(event.key)) {
				document.getElementById('nombre').style.border = "1px solid #00cc00";
			} else {
				if (event.keyCode == 8 || event.keyCode == 32) {} else {
					event.preventDefault();
				}
			}
		});
		const $email =document.querySelector("#email");
		const patronemail = /[a-zA-Z]+/;
	
		$email.addEventListener("keydown", event => {
			if (patronemail.test(event.key)) {
				document.getElementById('email').style.border = "1px solid #00cc00";
			} else {
				if (event.keyCode == 8 || event.keyCode == 32) {} else {
					event.preventDefault();
				}
			}
		});
		const $app =document.querySelector("#app");
		const patronapp = /[a-zA-Z]+/;
	
		$app.addEventListener("keydown", event => {
			if (patronapp.test(event.key)) {
				document.getElementById('app').style.border = "1px solid #00cc00";
			} else {
				if (event.keyCode == 8 || event.keyCode == 32) {} else {
					event.preventDefault();
				}
			}
		});
		const $apm =document.querySelector("#apm");
		const patronapm = /[a-zA-Z]+/;
	
		$app.addEventListener("keydown", event => {
			if (patronapm.test(event.key)) {
				document.getElementById('apm').style.border = "1px solid #00cc00";
			} else {
				if (event.keyCode == 8 || event.keyCode == 32) {} else {
					event.preventDefault();
				}
			}
		});
	
		const $tel = document.querySelector("#tel");
		const patrontel = /[0-9\.]+/;
	
		$tel.addEventListener("keydown", event => {
			if (patrontel.test(event.key)) {
				document.getElementById('tel').style.border = "1px solid #00cc00";
			} else {
				if (event.keyCode == 8 || event.keyCode == 32) {} else {
					event.preventDefault();
				}
			}
		});
		const $fn = document.querySelector("#fn");
		const patronfn = /[0-9/]+/;
	
		$fn.addEventListener("keydown", event => {
			if (patronfn.test(event.key)) {
				document.getElementById('fn').style.border = "1px solid #00cc00";
			} else {
				if (event.keyCode == 8 || event.keyCode == 32) {} else {
					event.preventDefault();
				}
			}
		});
		const $pass = document.querySelector("#pass");
		const patronpass = /[a-zA-Z/0-9/-/_/.]+/;
	
		$pass.addEventListener("keydown", event => {
			if (patronpass.test(event.key)) {
				document.getElementById('pass').style.border = "1px solid #00cc00";
			} else {
				if (event.keyCode == 8 || event.keyCode == 32) {} else {
					event.preventDefault();
				}
			}
		});
		
	</script>
</body>

</html><?php /**PATH C:\desarrolloweb\xampp1\htdocs\IDGS-81-main\resources\views/templates/registrarse.blade.php ENDPATH**/ ?>