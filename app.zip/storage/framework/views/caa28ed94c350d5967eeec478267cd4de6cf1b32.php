<!DOCTYPE HTML>
<html>
	<head>
		<title>Menu</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />
		<script>

		</script>
	</head>

<!-- Sidebar -->
<div id="sidebar">
						<div class="inner">

													<!-- Menu -->
								<nav id="menu">
									<header class="major">
										<h2>Menu</h2>
										<?php if(session('session_tipo') == 3): ?>
										 <h4>Hola <?php echo e(session('session_name')); ?></h4>
										<?php endif; ?>
										<?php if(session('session_tipo') == 1): ?>
										<h4>Hola <?php echo e(session('session_name')); ?></h4>
										<?php endif; ?>
										
									</header>
									<ul>
										<?php if(session('session_tipo') == 3): ?>
										<li><a href="<?php echo e(route('home')); ?>">Pagina de Inicio</a></li>
										<?php endif; ?>
										<?php if(session('session_tipo') == 0): ?>
										<li><a href="<?php echo e(route('home')); ?>">Pagina de Inicio</a></li>
										<?php endif; ?>
										
										<?php if(session('session_tipo') == 3): ?>
										<li><a href="<?php echo e(route('catalogo')); ?>">Catalogo de productos</a></li>
										<?php endif; ?>
										<?php if(session('session_tipo') == 0): ?>
										<li><a href="<?php echo e(route('catalogo')); ?>">Productos</a></li>
										<?php endif; ?>
										<li>
											<span class="opener">Sesion/Cliente</span>
											<ul>
												<?php if(session('session_tipo') == 0): ?>
												<li><a href="<?php echo e(route('registrarse')); ?>">Registrarse</a></li>
										<?php endif; ?>
												
												
												<?php if(session('session_tipo') == 1): ?>
												<li><a href="<?php echo e(route('detalleUsuario')); ?>">Ver perfil</a></li>
										<?php endif; ?>
										<?php if(session('session_tipo') == 3): ?>
												<li><a href="<?php echo e(route('detalleUsuario')); ?>">Ver perfil</a></li>
												
										<?php endif; ?>
									
										<?php if(session('session_tipo') == 1): ?>
										<li><a href="<?php echo e(route ('logout')); ?>">Cerrar Sesion</a></li>
												
										<?php endif; ?>
										<?php if(session('session_tipo') == 3): ?>
										<li><a href="<?php echo e(route ('logout')); ?>">Cerrar Sesion</a></li>
												
										<?php endif; ?>
										
										<?php if(session('session_tipo') == 0): ?>
										<li><a href="<?php echo e(route('iniciar_sesion')); ?>">Iniciar sesion</a></li>
										<?php endif; ?>
												
												

											</ul>
										</li>
										<?php if(session('session_tipo') == 1): ?>
										<li>
											<span class="opener">Usuarios</span>
											<ul>
												<li><a href="<?php echo e(route('registrarse')); ?>">Registrar Usuarios</a></li>
												<li><a href="<?php echo e(route('usuarios')); ?>">Ver lista de Usuarios</a></li>
												
											</ul>
										</li>
										<li>
											<span class="opener">Productos</span>
											<ul>
												<li><a href="<?php echo e(route('registrarProductos')); ?>">Registrar Productos</a></li>
												<li><a href="<?php echo e(route('productos')); ?>">Ver lista de productos</a></li>
												
											</ul>
										</li>
										<li>
											<span class="opener">Ventas</span>
											<ul>
												<!-- <li><a href="<?php echo e(route('registrarVentas')); ?>">Registrar Nueva Venta</a></li> -->
												<li><a href="<?php echo e(route('ventas')); ?>">Ver Registro de Ventas</a></li>
												<li><a href="<?php echo e(route('reporte')); ?>">Reporte de Ventas</a></li>
											</ul>
										</li>
										
										<li>
											<span class="opener">Materiales</span>
											<ul>
												<li><a href="<?php echo e(route('registrarMateriales')); ?>">Registrar Material</a></li>
												<li><a href="<?php echo e(route('materiales')); ?>">Ver Registro de Materiales</a></li>
											</ul>
										</li>
										<?php endif; ?>
										
										
									</ul>
								</nav>
								<section>
									<header class="major">
										<h2>Contactanos</h2>
									</header>
									<p>Si tienes alguna duda, contactanos nosotros la resolveremos</p>
									<ul class="contact">
										<li class="icon solid fa-envelope"><a href="#">information@luminosite.tld</a></li>
										<li class="icon solid fa-phone">(000) 000-0000</li>
										<li class="icon solid fa-home">UTVT<br />
										Toluca, México 0000-0000</li>
										<a href="<?php echo e(route('aviso')); ?>">Aviso de Privacidad</a>
									</ul>
								</section>

						</div>
					</div><?php /**PATH C:\desarrollo_web\xampp2\htdocs\IDGS-81-main\resources\views/layouts/menu.blade.php ENDPATH**/ ?>