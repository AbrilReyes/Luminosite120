<!DOCTYPE HTML>

<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

				<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				<!-- Banner -->
				<section id="banner">
					<div class="content">
						<header>
                        <h1>Nos encontramos en:</h1>
                        <p><h2>Ignacio López Rayon 104, Centro, 50000 Toluca de Lerdo, Méx.</h2></p>
						</header>
						<div style="width: auto; height: 500px;">
                             <?php echo Mapper::render(); ?>

                        </div>
                        <br>

						<ul class="actions">
							<li><a href="<?php echo e(route('home')); ?>" class="button big">Regresar</a></li>
						</ul>
					</div>
				</section>

			</div>
		</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>

</html>





<?php /**PATH C:\desarrollo_web\xampp2\htdocs\sistemaok\resources\views/templates/mapa.blade.php ENDPATH**/ ?>