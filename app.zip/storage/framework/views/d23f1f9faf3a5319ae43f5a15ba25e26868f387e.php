<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>

<style>
	.card {
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
		transition: 0.3s;

		border-radius: 5px;
		text-align: center;
	}

	.card:hover {
		box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
	}

	img {
		border-radius: 5px 5px 0 0;
	}

	.container {
		padding: 2px 16px;
	}
</style>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

				<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


				<h2>Detalle Producto</h2>

				<div>
					<div class="card">
						<img src="<?php echo e(asset('img/'.$usu->img)); ?>" alt="Imagen" width="150" height="150">
						<div class="container" >
					Nombre del producto: <?php echo e($usu->nombre_producto); ?> <br>
							Descripcion: <?php echo e($usu->descripcion); ?> <br>
							Existencias: <?php echo e($usu->no_existencias); ?> <br>
							Precio: <?php echo e($usu->precio); ?> <br>
							Medida: <?php echo e($usu->medida); ?> <br>
							Precio de oferta: <?php echo e($usu->precio_oferta); ?> <br>
						   <br>
							<form action="<?php echo e(route('cart.add')); ?>" method="post">
								<?php echo csrf_field(); ?>
								<input type="hidden" name="producto_id" value="<?php echo e($usu->id_producto); ?>">
								<?php if(session('session_tipo') == 3): ?>
								<input type="submit" name="btn" class="btn btn-success" value="AÑADIR AL CARRITO">
										<?php endif; ?>
										<?php if(session('session_tipo') == 0): ?>
										<a href="<?php echo e(route('iniciar_sesion')); ?>" class="button big" >AÑADIR AL CARRITO</a><br>								
										<?php endif; ?>
							</form>
							</form>
							<a href="<?php echo e(route('catalogo')); ?>" class="button big">Regresar</a><br>

						</div>
					</div>




				</div>

			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\desarrollo_web\xampp2\htdocs\sistemaok\resources\views/templates/detalle_producto.blade.php ENDPATH**/ ?>