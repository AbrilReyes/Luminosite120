<!DOCTYPE HTML>
<html>

<head>
	<title>Registrar Productos</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


				<form action="<?php echo e(route ('guardarProductos')); ?>" method="POST" name="nuevo" enctype="multipart/form-data">

					<?php echo e(csrf_field()); ?>


					<div >
						Nombre Del Producto : <input type="text" name="nombre_producto" value="<?php echo e(old('nombre_producto')); ?>">
					</div>
					<?php if($errors->first('nombre_producto')): ?> <i><?php echo e($errors -> first ('nombre_producto')); ?></i><?php endif; ?>

					<div >
						Numero de existencias : 
					<input type="text" name="no_existencias" value="<?php echo e(old('no_existencias')); ?>">
					</div> 
					<?php if($errors->first('no_existencias')): ?> <i><?php echo e($errors -> first ('no_existencias')); ?></i><?php endif; ?>
					

					<div >
						Precio :
					<input type="text" name="precio">
					</div>
					<?php if($errors->first('precio')): ?> <i><?php echo e($errors -> first ('precio')); ?></i><?php endif; ?>

					<div >
					<!-- como cambiar el tamaño -->
						Descripcion : 
					<input type="text" name="descripcion" value="<?php echo e(old('descripcion')); ?>">
					</div>
					<?php if($errors->first('descripcion')): ?> <i><?php echo e($errors -> first ('descripcion')); ?></i><?php endif; ?>

					<div >
						Medida : 
					<input type="text" name="medida">
					</div>
					<?php if($errors->first('medida')): ?> <i><?php echo e($errors -> first ('medida')); ?></i><?php endif; ?>

					<div >
						Precio oferta : 
					<input type="text" name="precio_oferta">
					</div>
					<?php if($errors->first('precio_oferta')): ?> <i><?php echo e($errors -> first ('precio_oferta')); ?></i><?php endif; ?>
					
					Imagen : <input type="file" name="img">

					<hr>
				

					<input type="submit" value="Enviar">
				</form>

			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\desarrollo_web\xampp2\htdocs\sistemaok\resources\views/templates/registrar_productos.blade.php ENDPATH**/ ?>