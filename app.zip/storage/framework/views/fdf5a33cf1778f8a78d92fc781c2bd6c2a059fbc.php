
<!DOCTYPE HTML>

<html>

<head>
	<title>Inicio de Sesion</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>
<style>
	.alinear{
		text-align: center;
	}
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

				
			   <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			   <?php if($errors->any()): ?>
			   <div class="alert alert-danger">
				   <ul>
					   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					   <li><?php echo e($error); ?></li>
					   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				   </ul>
			   </div><br />
			   <?php endif; ?>

				<?php if(empty(session('session_id'))): ?>

				<form action="<?php echo e(route ('validar')); ?>" method="POST" name="nuevo">

					<?php echo e(csrf_field()); ?>


					<div>
						Email : <input type="email" name="email"><br>
					</div>
					
					<?php if($errors->first('email')): ?> <i><?php echo e($errors -> first ('email')); ?></i><?php endif; ?>

					<div>
						Password : <input type="password" name="pass"><br>
						
					</div>
					<div>
						<?php if($errors->first('pass')): ?> <i><?php echo e($errors -> first ('pass')); ?></i><?php endif; ?> 
					</div>
					
						<div class="form-group mt-4 mb-4">
							<div class="captcha">
								<span><?php echo captcha_img(); ?></span>
								<button type="button" class="btn btn-danger" class="reload" id="reload">
									&#x21bb;
								</button>
							</div>
						</div>
		
						<div class="form-group mb-4">
							<input id="captcha" type="text" class="form-control" placeholder="Enter Captcha" name="captcha">
						</div>
					
					<input type="submit" value="Ingresar">
					
					

				</form>

				<?php else: ?>
				<?php if(session('session_tipo') == 3): ?>
				<div class="alinear">
					<h1>Hola <?php echo e(session('session_name')); ?></h1>
					<h1>Ya estas Logeado, Ve a comprar algunas joyas.</h1>
					</div>
	
			   <?php endif; ?>
			   <?php if(session('session_tipo') == 1): ?>
			   <div class="alinear">
				<h1>Bienvenido <?php echo e(session('session_name')); ?></h1>
				<h1>Ya estas Logeado.</h1>
				</div>
	
			   <?php endif; ?>
			    

				<?php endif; ?>


			</div>
		</div>
		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
<script type="text/javascript">
    $('#reload').click(function () {
        $.ajax({
            type: 'GET',
            url: 'reload-captcha',
            success: function (data) {
                $(".captcha span").html(data.captcha);
            }
        });
    });

    </script>

</html><?php /**PATH C:\desarrollo_web\xampp2\htdocs\sistemaok\resources\views/templates/iniciar_sesion.blade.php ENDPATH**/ ?>