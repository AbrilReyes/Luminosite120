<!DOCTYPE HTML>
<html>

<head>
	<title>Registro de Ventas</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

				<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<h4>Ventas registradas</h4>
				<div>
					<table>
						<thead>
							<tr>
								<th>
									<h3>Monto total</h3>
								</th>
								<th>
									<h3>Dirección relacionada</h3>
								</th>
								<th>
									<h3>Cliente</h3>
								</th>
								<th>
									<h3>Editar Registro</h3>
								</th>
								<th>
									<h3>Eliminar Registro</h3>
								</th>
							</tr>
						</thead>
						<?php $__currentLoopData = $usus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tbody>
							<tr>
								<td>$ <?php echo e($usu->monto_total); ?></td>

								<?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<?php if($todo->clientes_id == $usu->clientes_id ): ?>

								<td><?php echo e($todo->calle); ?> <br>
									<?php echo e($todo->numero_direccion); ?> <br>
									<?php echo e($todo->estado); ?></td>

								<?php endif; ?>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								<?php $__currentLoopData = $comps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($usu->clientes_id == $comp->id_usuario ): ?>
								<td><?php echo e($comp->app); ?> <?php echo e($comp->apm); ?> <?php echo e($comp->nombre); ?></td>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<td>
									<h3><a href="<?php echo e(route('modificarVentas', ['id' => $usu->id_venta])); ?>"><i class="fas fa-pen-square"></i> Editar</a></h3>
								</td>
								<td>
									<h3><a href="<?php echo e(route('borrarVenta', ['id' => $usu->id_venta])); ?>"><i class="fas fa-trash-alt"></i> Eliminar</a></h3>
								</td>
							</tr>
						</tbody>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</table>
				</div>

			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\desarrollo_web\xampp2\htdocs\IDGS91\resources\views/templates/ventas.blade.php ENDPATH**/ ?>