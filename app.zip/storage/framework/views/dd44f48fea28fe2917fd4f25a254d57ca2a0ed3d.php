
<!DOCTYPE HTML>
<html>
	<head>
		<title>Usuarios</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

	</head>

	<body class="is-preload">

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

						<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

								
<h2>Usuarios registrados</h2>

<div>
	<table>
		<thead>
			<tr>
				<th><h3>ID</h3></th>
				<th><h3>Tipo Usuario</h3></th>
				<th><h3>Cuenta</h3></th>
				<th><h3>Nombre</h3></th>
			    <th><h3>Email</h3></th>
				<th><h3>Imagen</h3></th>
				<th><h3>Editar Registro</h3></th>
				<th><h3>Eliminar Registro</h3></th>
			</tr>
		</thead>
		<?php $__currentLoopData = $usus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tbody>
			<tr>
				<td><?php echo e($usu->id_usuario); ?></td>
				<td><?php echo e($usu->tipo_usuario); ?></td>
				<td><?php echo e($usu->matricula); ?></td>
				<td><?php echo e($usu->app); ?> <?php echo e($usu->apm); ?> <?php echo e($usu->nombre); ?></td>
			    <td><?php echo e($usu->email); ?></td>
				<td><img src="<?php echo e(asset('img/' .$usu->img)); ?>" alt="<?php echo e($usu->img); ?>" width="40" height="40"  class="img-rounded"></td>
				<td><h3><a href="<?php echo e(route('modificar', ['id' => $usu->id_usuario])); ?>"><i class="fas fa-pen-square"></i> Editar perfil</a></h3></td>
				<td><h3><a href="<?php echo e(route('borrar', ['id' => $usu->id_usuario])); ?>"><i class="fas fa-trash-alt"></i> Eliminar usuario</a></h3></td>
							
			</tr>
		</tbody>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<!-- <tfoot>
												<tr>
													<td colspan="2"></td>
													<td>100.00</td>
												</tr>
											</tfoot> -->
	</table>
</div>



<!-- <div id="">
					<div class=""></div>
					<h1>
						
					</h1>
					<div class="">

					 <br>
						
						 <br>
						<?php echo e($usu->pass); ?> <br>
						<?php echo e($usu->img); ?> <br>
						<?php echo e($usu->id_grupo); ?> <br>
						<?php echo e($usu->id_tipo); ?> <br>
						<?php echo e($usu->activo); ?> <br>
					</div>
				</div> -->

						</div>
					</div>

				<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			</div>

			<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</body>
</html>
<?php /**PATH C:\desarrollo_web\xampp2\htdocs\sistemaok\resources\views/templates/usuarios.blade.php ENDPATH**/ ?>