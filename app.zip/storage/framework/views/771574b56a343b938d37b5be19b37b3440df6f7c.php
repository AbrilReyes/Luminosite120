<!-- Header -->
<header id="header">
	<?php if(session('session_tipo') == 0): ?>
	<h2><a href="<?php echo e(route('home')); ?>" class="logo"><strong>Joyeria</strong> Luminoseté</a></h2>
	<?php endif; ?>
	<?php if(session('session_tipo') == 1): ?>
	<h2><a href="<?php echo e(route('detalleUsuario')); ?>" class="logo"><strong>Joyeria</strong> Luminoseté</a></h2>
	<?php endif; ?>
	<?php if(session('session_tipo') == 3): ?>
	<h2><a href="<?php echo e(route('home')); ?>" class="logo"><strong>Joyeria</strong> Luminoseté</a></h2>
	<?php endif; ?>
	<?php if(empty(session('session_id'))): ?>
	<h1></h1>
	<?php else: ?>
	
	

	<?php endif; ?>
	<ul class="icons">

		<?php if(!empty(session('session_id'))): ?>

		

		<?php if(count(Cart::getContent())): ?>
		<?php if(session('session_tipo') == 3): ?>
		<a href="<?php echo e(route('carrito')); ?>" class="button big"> VER CARRITO </a>
		<?php endif; ?>
		

		<?php endif; ?>

		<?php else: ?>
		<h1></h1>
		<?php endif; ?>

	</ul>
</header><?php /**PATH C:\desarrollo_web\xampp2\htdocs\IDGS91\resources\views/layouts/header.blade.php ENDPATH**/ ?>